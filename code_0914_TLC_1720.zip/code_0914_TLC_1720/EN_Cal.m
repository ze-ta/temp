function entropy = EN_Cal(probs)
%% Calculate entropy
entropy = 0;
for i = 1:length(probs)
    if(probs(i) <= 1e-8)
        entropy = entropy + 0;
    else
        entropy = entropy - probs(i).*log2(probs(i));
    end
end
end