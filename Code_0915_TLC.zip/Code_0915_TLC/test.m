clear all
close all
clc

mu = -3;
sigma = 0.35;

% sigma = [0.35 0.25];

V1 = 0;

x =  -10:0.1:10;

Giv  = 0.5 + 0.5 * erf((x - mu)/(sqrt(2)*sigma));
Gn   = normcdf(x, mu, sigma);


plot(x, G_iv, 'r-')
hold on
plot(x, Giv, 'g-')
plot(x, Gn, 'b-*')
grid on