clear all
close all
clc

N           = 8;   % TLC
m           = 14;  % number of read threshold voltage
delta_g     = 50;
delta       = 0.5;
epsilon     = 1e-3;
zeta        = 1e-6;
iter_num    = 10000;
plot_fig    = 1;

% mu          = [-3, 1, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0];
mu          = [-7, -5, -3, -1, 1, 3, 5, 7];
Es          = 0;
for i = 1:N
    Es = Es + mu(1, i)^2/N;
end
SNR_dB      = 8.4;                  % SNR = 10 dB
N0          = Es*10^(-0.1*SNR_dB); % AWGN N0
% sigma2      = [0.35, 0.12, 0.13, 0.15, 0.2, 0.15, 0.2, 0.15];
% sigma2      = ones(1, 8) * N0/2;   % Noise Variance
% sigma2(1)   = N0;
sigma2      = [N0, N0/2, N0/2, N0/4, N0/4, N0/8, N0/8, N0/8];
sigma       = zeros(1, length(sigma2));
for i = 1:length(sigma2)
    sigma(i) = sqrt(sigma2(i));
end
% sigma
gap         = 0.4;
gamma       = zeros(iter_num, m);
% gamma(1, :) = [-4, -2, 0, 1, 1.2, 1.6, 2.0, 2.4, 2.8, 3.2, 3.6, 4.0, 4.4, 4.8];
% gamma(1, :) = [-4, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0];
cp          = [-6, -4, -2, 0, 2, 4, 6]; % cross point
gamma(1, :) = [cp(1)-gap, cp(1)+gap, cp(2)-gap, cp(2)+gap, cp(3)-gap, cp(3)+gap, cp(4)-gap, cp(4)+gap, cp(5)-gap, cp(5)+gap, cp(6)-gap, cp(6)+gap, cp(7)-gap, cp(7)+gap];

x = -10:0.01:10;
PDF_Func1 = normpdf(x, mu(1), sigma(1)) + 0.010*randn(1,length(x));
PDF_Func2 = normpdf(x, mu(2), sigma(2)) + 0.005*randn(1,length(x));
PDF_Func3 = normpdf(x, mu(3), sigma(3)) + 0.005*randn(1,length(x));
PDF_Func4 = normpdf(x, mu(4), sigma(4)) + 0.005*randn(1,length(x));
PDF_Func5 = normpdf(x, mu(5), sigma(5)) + 0.005*randn(1,length(x));
PDF_Func6 = normpdf(x, mu(6), sigma(6)) + 0.005*randn(1,length(x));
PDF_Func7 = normpdf(x, mu(7), sigma(7)) + 0.005*randn(1,length(x));
PDF_Func8 = normpdf(x, mu(8), sigma(8)) + 0.005*randn(1,length(x));

if(plot_fig)
    figure(1)
    plot(x, PDF_Func1, '-');
    hold on
    plot(x, PDF_Func2, 'r-');
    plot(x, PDF_Func3, 'Color', [0.3010 0.7450 0.9330]);
    plot(x, PDF_Func4, 'Color', [0.8500 0.3250 0.0980]);
    plot(x, PDF_Func5, 'Color', [0.4660 0.6740 0.1880]);
    plot(x, PDF_Func6, 'Color', [0.9290 0.6940 0.1250]);
    plot(x, PDF_Func7, 'Color', [0.0000 0.4470 0.7410]);
    plot(x, PDF_Func8, 'Color', [0.4940 0.1840 0.5560]);
    grid on
end

MI           = zeros(1, iter_num);
[tmp_MI0, ~] = MI_Cal_All(gamma(1, :), sigma2, mu);
MI(1, 1)     = tmp_MI0;
it           = 1;
learn_ratio  = zeros(1, iter_num);
while(delta_g > zeta)
    partial_g      = zeros(1, m);
%     epsilon_matrix = epsilon * eye(m);
    epsilon_matrix = epsilon * ones(m);
    for i = 1:m
        [tmp1_gi, ~] = MI_Cal_All(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
        [tmp2_gi, ~] = MI_Cal_All(gamma(it, :), sigma2, mu);
        partial_g(i) = (tmp1_gi - tmp2_gi)/epsilon/sqrt(m);
    end
%     partial_g
    gamma(it + 1, :) = gamma(it, :) + delta * partial_g;
    [tmp_MI, prob_trans] = MI_Cal_All(gamma(it + 1, :), sigma2, mu);
%     gamma(it + 1, :)
%     prob_trans
    if(tmp_MI - MI(1, it) < 0)
        gamma(it + 1, :) = gamma(it, :) - delta * partial_g;
        [tmp_MI, prob_trans] = MI_Cal_All(gamma(it + 1, :), sigma2, mu);
    end
    MI(1, it + 1)    = tmp_MI;
    delta_g          = MI(1, it + 1) - MI(1, it);
    learn_ratio(1, it) = delta_g;
    fprintf(">> delta g = %.4e\n", delta_g);
    fprintf(">> Current iteration number is %d\n", it);
    fprintf(">> Current MI is %.4f\n", MI(1, it + 1));
    it = it + 1;
end
it
gamma(1, :)
gamma(it, :)
if(plot_fig)
    figure(2)
    plot(1:it, gamma(1:it,  1), 'r-');
    hold on
    plot(1:it, gamma(1:it,  2), 'g-');
    plot(1:it, gamma(1:it,  3), 'b-');
    plot(1:it, gamma(1:it,  4), 'c-');
    plot(1:it, gamma(1:it,  5), 'y-');
    plot(1:it, gamma(1:it,  6), 'k-');
    plot(1:it, gamma(1:it,  7), 'r-.');
    plot(1:it, gamma(1:it,  8), 'g-.');
    plot(1:it, gamma(1:it,  9), 'Color', [0.4940 0.1840 0.5560]);
    plot(1:it, gamma(1:it, 10), 'Color', [0.3010 0.7450 0.9330]);
    plot(1:it, gamma(1:it, 11), 'Color', [0.8500 0.3250 0.0980]);
    plot(1:it, gamma(1:it, 12), 'Color', [0.4660 0.6740 0.1880]);
    plot(1:it, gamma(1:it, 13), 'Color', [0.9290 0.6940 0.1250]);
    plot(1:it, gamma(1:it, 14), 'Color', [0.0000 0.4470 0.7410]);
    
%     plot(1:it, gamma(1:it, 3), 'Color', [0.3010 0.7450 0.9330], 'Marker', '*');
%     plot(1:it, gamma(1:it, 4), 'Color', [0.8500 0.3250 0.0980], 'Marker', '*');
%     plot(1:it, gamma(1:it, 5), 'Color', [0.4660 0.6740 0.1880], 'Marker', '*');
%     plot(1:it, gamma(1:it, 6), 'Color', [0.9290 0.6940 0.1250], 'Marker', '*');
%     plot(1:it, gamma(1:it, 7), 'Color', [0.0000 0.4470 0.7410], 'Marker', '*');
%     plot(1:it, gamma(1:it, 8), 'Color', [0.4940 0.1840 0.5560], 'Marker', '*');
    grid on
    xlabel('Iterations');ylabel('Read Threshold Voltage');
    title('Read Threshold Voltage vs Iterations')
end

if(plot_fig)
    figure(3)
    len = length(find(MI > 0));
    x = 1:len;
    y = MI(1:len);
    plot(x, y, 'Color', [0.4660 0.6740 0.1880]);
    grid on;
    xlabel('Iterations');ylabel('Mutual Infomation');
    title('MI vs Iterations');
end

if(plot_fig)
    figure(4)
    plot(1:it, learn_ratio(1:it), 'r');
    grid on;
    xlabel('Iterations');ylabel('Learning Ratio');
end

LLR_Struct.mu_list        = mu;
LLR_Struct.sigma_list     = sigma2;
Option.Type               = 1;                % 表示输入最佳读电压列表、分区个数和分区间隔来计算LLR的模式
Option.ORVList            = gamma(it, :);     % Optimal Read Voltage List
Option.partition_num      = 4;                % 分区个数:是指两个分布态之间的LLR的分区的个数, 以最佳读电压为中心计算LLR, 7次读操作分别计算LLR
Option.partition_interval = 0.1;              % 分区间隔

% NormDistFunc = @(x, mu_val, sigma_val) 1./(sqrt(2.*pi).*sigma_val).*exp(-(x-mu_val).^2./(2.*sigma_val.^2));
% G_iv = integral(@(x)NormDistFunc(x, -7, 0.35), -Inf, 1, 'AbsTol', 1e-7)

% [mu(1), sigma(1)]
% fun = @(x) 1./(sqrt(2*pi).*1.2621).*exp(-(x+7).^2./(2*1.2621.^2));
% G_iv = integral(fun, -Inf, 0)

% Vol1 = 1;
% G_iv = normcdf(1, mu(1), sigma1(1));

% Option.Type = 2 %表示直接输入读电压分区间隔来计算LLR的模式
% Option.LLR_Partition_Voltage %读电压分区间隔
LLR_and_DV_Sturct = Cal_TLC_LLR(LLR_Struct, Option);
% [LLR_and_DV_Sturct.LSB_LLR.' LLR_and_DV_Sturct.MSB_LLR.' LLR_and_DV_Sturct.USB_LLR.']
% [LLR_and_DV_Sturct.LSB_LLR.' LLR_and_DV_Sturct.MSB_LLR.' LLR_and_DV_Sturct.USB_LLR.' LLR_and_DV_Sturct.LSB_LLR_float.' LLR_and_DV_Sturct.MSB_LLR_float.' LLR_and_DV_Sturct.USB_LLR_float.']