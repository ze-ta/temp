clear all
close all
clc

N           = 4; % four pdf
m           = 6; % number of read threshold voltage
delta_g     = 10;
delta       = 0.5;
epsilon     = 1e-3;
zeta        = 1e-8;
iter_num    = 500;
gamma       = zeros(iter_num, m);
gamma(1, :) = [-3, -2, -1, 1, 2, 3];
mu          = [-3, -1, +1, +3];
Es          = 0;
for i = 1:N
    Es = Es + mu(1, i).^2/N;
end
SNR_dB      = 10;
N0          = Es*10^(-0.1*SNR_dB);
sigma2      = N0;
MI          = zeros(1, iter_num);
[tmp_MI0, prob_trans] = MI_Cal(gamma(1, :), sigma2, mu);
MI(1, 1)    = tmp_MI0;
% prob_trans
it          = 1;
while(delta_g > zeta)
    partial_g      = zeros(1, m);
    epsilon_matrix = epsilon * eye(m);
    for i = 1:m
        [tmp1_gi, ~] = MI_Cal(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
        [tmp2_gi, ~] = MI_Cal(gamma(it, :), sigma2, mu);
        partial_g(i) = (tmp1_gi - tmp2_gi)/epsilon;
%         partial_g(i) = partial_g(i)/epsilon;
%         partial_g(i) = MI_Cal(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
    end
%     partial_g
    gamma(it + 1, :) = gamma(it, :) + delta * partial_g;
    [tmp_MI, ~]   = MI_Cal(gamma(it + 1, :), sigma2, mu);
    MI(1, it + 1) = tmp_MI;
    delta_g       = MI(1, it + 1) - MI(1, it);
    fprintf(">> delta g = %.4e\n", delta_g);
    gamma(it, :)
    fprintf(">> Current MI is %.4f\n", MI(1, it + 1));
    it = it + 1;
end
% MI'