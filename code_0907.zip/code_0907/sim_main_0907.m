clear all
close all
clc

m           = 6; % number of read threshold voltage
N           = 4; % four pdf
delta_g     = 10;
delta       = 0.5;
epsilon     = 1e-3;
zeta        = 1e-8;
iter_num    = 100;
gamma       = zeros(iter_num, 6);
gamma(1, :) = [-3, -2, -1, 1, 2, 3];
SNR         = 10;
mu          = [-3, -1, +1, +3];
Es          = (mu(1, 1)^2 + mu(1, 2)^2 + mu(1, 3)^2 + mu(1, 4))/4;
N0          = Es*10^(-0.1*SNR);
sigma2      = N0;
MI          = zeros(1, iter_num);
MI(1, 1)    = MI_Cal(gamma(1, :), sigma2, mu);
MI(1, 1)
it          = 1;
while(delta_g > zeta)
    partial_g        = zeros(1, m);
    epsilon_matrix   = epsilon * eye(m);
    for i = 1:m
%         partial_g(i) = MI_Cal(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu)/epsilon;
        partial_g(i) = MI_Cal(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
    end
    gamma(it + 1, :) = gamma(it, :) + delta * partial_g;
    MI(1, it + 1)    = MI_Cal(gamma(it + 1, :), sigma2, mu);
    delta_g          = MI(1, it + 1) - MI(1, it);
    fprintf(">> Current iteration number is %d, gamma vector is: [%.4f, %.4f, %.4f, %.4f, %.4f, %.4f]\n", it, gamma(it, 1), gamma(it, 2), gamma(it, 3), gamma(it, 4), gamma(it, 5), gamma(it, 6));
    fprintf(">> Current MI is %.4f\n", MI(1, it + 1));
    it = it + 1;
end