clear all
close all
clc

N           = 8;  % six pdf
m           = 14;  % number of read threshold voltage
delta_g     = 10;
delta       = 0.5;
epsilon     = 1e-3;
zeta        = 1e-8;
iter_num    = 5000;
gamma       = zeros(iter_num, m);
gamma(1, :) = [-2, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0];
% mu          = [-3, 0, 0.5, 1, 1.5, 2, 2.5, 3];
mu          = [-4, -3, -2, -1, 1, 2, 3, 4];
Es          = 0;
for i = 1:N
    Es = Es + mu(1, i).^2/N;
end
SNR_dB      = 10;                    % SNR = 10 dB
N0          = Es*10^(-0.1*SNR_dB);   % AWGN N0
sigma2      = N0;                    % Noise variance
MI          = zeros(1, iter_num);
[tmp_MI0, prob_trans] = MI_Cal_All(gamma(1, :), sigma2, mu);
MI(1, 1)    = tmp_MI0;
it          = 1;
while(delta_g > zeta)
    partial_g      = zeros(1, m);
    epsilon_matrix = epsilon * eye(m);
    for i = 1:m
        [tmp1_gi, ~] = MI_Cal_All(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
        [tmp2_gi, ~] = MI_Cal_All(gamma(it, :), sigma2, mu);
        partial_g(i) = (tmp1_gi - tmp2_gi)/epsilon;
    end
    gamma(it + 1, :) = gamma(it, :) + delta * partial_g;
    [tmp_MI, ~]   = MI_Cal_All(gamma(it + 1, :), sigma2, mu);
    MI(1, it + 1) = tmp_MI;
    delta_g       = MI(1, it + 1) - MI(1, it);
    fprintf(">> delta g = %.4e\n", delta_g);
    gamma(it + 1, :)
    fprintf(">> Current iteration number is %d\n", it);
    fprintf(">> Current MI is %.4f\n", MI(1, it + 1));
    it = it + 1;
end