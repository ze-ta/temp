function [MI, prob_trans] = MI_Cal_tmp(gamma, sigma2, mu)
N     = 2;
m     = length(gamma);
% gray_code = [111, 110, 100, 000, 010, 011, 001, 101];
f_1 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 1)).^2./(2.*sigma2));
f_0 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 2)).^2./(2.*sigma2));
prob_trans = zeros(N, m + 1);
prob_trans(1, 1) = 1/(2*pi*sigma2)*integral(f_1, -inf, gamma(1, 1));
prob_trans(1, 2) = 1/(2*pi*sigma2)*integral(f_1, gamma(1, 1), gamma(1, 2));
prob_trans(1, 3) = 1/(2*pi*sigma2)*integral(f_1, gamma(1, 2), +inf);

prob_trans(2, 1) = 1/(2*pi*sigma2)*integral(f_0, -inf, gamma(1, 1));
prob_trans(2, 2) = 1/(2*pi*sigma2)*integral(f_0, gamma(1, 1), gamma(1, 2));
prob_trans(2, 3) = 1/(2*pi*sigma2)*integral(f_0, gamma(1, 2), +inf);

prob_vect = zeros(1, m + 1);
for i = 1:m+1
    prob_vect(i) = (prob_trans(1, i) + prob_trans(2, i))/2;
end
H_Y = ent_cal(prob_vect);
H_YX = 0;
for i = 1:2
    H_YX = H_YX + ent_cal(prob_trans(i, :))/2;
end
MI = H_Y - H_YX;
end