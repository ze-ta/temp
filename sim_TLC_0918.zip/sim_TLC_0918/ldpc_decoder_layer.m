function [dec_out,it,chk_sum] = ldpc_decoder_layer(llr,MaxIt,EF,sim_para)
if nargin == 0
    llr    = randi([-7 7],1,17664);
    MaxIt  = 32;
    EF     = 256;
end
persistent Hbits;
persistent C2V;
persistent Rwt;
if (isempty(Rwt))
    Hbits = evalin('base','Hbits');
%     Hb = evalin('base','Hb');
    [r,c] = size(Hbits);
    tmpHb = Hbits;
    Rwt   = sum(Hbits(1:EF:end,:),2);
    C2V   = cell(r/EF,1);
    for ii = 1:r/EF
        C2V{ii} = uint16(mod(reshape(find(tmpHb((ii-1)*EF+(1:EF),:).'),[],EF).'-1,c)+1);
    end
    Hbits = sparse(Hbits);
    clear tmpHb;
end
app     = reshape(llr,EF,[]);
cn      = zeros(EF,sum(Rwt));
chk_sum = zeros(MaxIt,length(Rwt));
for it = 1:MaxIt
    for lay = 1:length(Rwt)
        Cnidx  = 1+sum(Rwt(1:lay-1)):sum(Rwt(1:lay));
        [app1,cn1] = ldpc_dec(app(C2V{lay}),cn(:,Cnidx),EF,sim_para);
        app(C2V{lay})  = app1;
        cn(:,Cnidx)    = cn1;
        dec_out        = app(:)>=0;
        chk_sum(it,lay) = sum(mod((Hbits)*dec_out,2));
        if (chk_sum(it,lay) == 0)
            break;
        end
    end
    if (chk_sum(it,lay) == 0)
        break;
    end
end
end
function [app,cn] = ldpc_dec(app,cn,ef,sim_para)
vn            = app - cn;
vn_sgn        = vn>=0;
vn_abs        = min(sim_para.sat_min,abs(vn).');
[Min,minPos]  = min(vn_abs);
Min           = Min.';
MinPosIdx     = (minPos-1)*ef+(1:ef);
vn_abs(minPos+(0:ef-1)*size(cn,2)) = inf;
[Smin,~]      = min(vn_abs);

flg2          = (Min>sim_para.bd(1,1)) & (Min<=sim_para.bd(1,2));
flg3          = (Min>sim_para.bd(1,2)) & (Min<=sim_para.bd(1,3));
flg4          = (Min>sim_para.bd(1,3)) ;
Min(flg2)     = Min(flg2) - sim_para.v(1,2);
Min(flg3)     = Min(flg3) - sim_para.v(1,3);
Min(flg4)     = Min(flg4) - sim_para.v(1,4);

flg2          = (Smin>sim_para.bd(2,1)) & (Smin<=sim_para.bd(2,2));
flg3          = (Smin>sim_para.bd(2,2)) & (Smin<=sim_para.bd(2,3));
flg4          = (Smin>sim_para.bd(2,3)) ;
Smin(flg2)    = Smin(flg2) - sim_para.v(1,2);
Smin(flg3)    = Smin(flg3) - sim_para.v(1,3);
Smin(flg4)    = Smin(flg4) - sim_para.v(1,4);
chkflg        = 1==mod(sum(vn_sgn,2),2);
cn_sgn        = 2*(chkflg~=vn_sgn)-1;
cn            = cn_sgn.*Min;
cn(MinPosIdx) = cn_sgn(MinPosIdx).*Smin;
app = vn + cn;
app = sign(app) .* min(abs(app),sim_para.sat_app);
end