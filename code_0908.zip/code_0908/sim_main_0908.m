clear all
close all
clc

m           = 6; % number of read threshold voltage
N           = 4; % four pdf
delta_g     = 10;
delta       = 0.5;
epsilon     = 1e-3;
zeta        = 1e-8;
iter_num    = 100;
gamma       = zeros(iter_num, 6);
gamma(1, :) = [-2, -2, -0, 0, 2, 2];
mu          = [-3, -1, +1, +3];
Es          = (mu(1, 1)^2 + mu(1, 2)^2 + mu(1, 3)^2 + mu(1, 4))/4;
SNR_dB      = 10;
N0          = Es*10^(-0.1*SNR_dB);
sigma2      = N0;
MI          = zeros(1, iter_num);
[tmp_MI0, prob_trans] = MI_Cal(gamma(1, :), sigma2, mu);
MI(1, 1)    = tmp_MI0;
% prob_trans
it          = 1;
while(delta_g > zeta)
    partial_g      = zeros(1, m);
    epsilon_matrix = epsilon * eye(m);
    for i = 1:m
        [tmp1_gi, ~] = MI_Cal(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
        [tmp2_gi, ~] = MI_Cal(gamma(it, :), sigma2, mu);
        partial_g(i) = (tmp1_gi - tmp2_gi)/epsilon;
%         partial_g(i) = partial_g(i)/epsilon;
%         partial_g(i) = MI_Cal(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
    end
%     partial_g
    gamma(it + 1, :) = gamma(it, :) + delta * partial_g;
    [tmp_MI, ~]   = MI_Cal(gamma(it + 1, :), sigma2, mu);
    MI(1, it + 1) = tmp_MI;
    delta_g       = MI(1, it + 1) - MI(1, it);
    fprintf(">> delta g = %.4e\n", delta_g);
    fprintf(">> Current iteration number is %d, gamma vector is: [%.4f, %.4f, %.4f, %.4f, %.4f, %.4f]\n", it, gamma(it, 1), gamma(it, 2), gamma(it, 3), gamma(it, 4), gamma(it, 5), gamma(it, 6));
    fprintf(">> Current MI is %.4f\n", MI(1, it + 1));
    it = it + 1;
end