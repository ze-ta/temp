clear all
close all
clc

m          = 6; % number of read threshold voltage
N          = 4; % four pdf
delta_g    = 0.5;
epsilon    = 1e-3;
zeta       = 1e-8;
iter_num   = 1000;
gamma      = zeros(iter_num, 6);
gamma(1, :) = [-2.4, -1.6, -0.4, 0.4, 1.6, 2.4];
N0     = 0.1;
mu     = [-3, -1, +1, +3];
sigma  = [1, 1, 1, 1];
f_11 = @(x)sqrt(2.*pi.*sigma(1, 1).^2).*exp(-(x-mu(1, 1)).^2./(2.*sigma(1, 1).^2));
f_10 = @(x)sqrt(2.*pi.*sigma(1, 2).^2).*exp(-(x-mu(1, 2)).^2./(2.*sigma(1, 2).^2));
f_00 = @(x)sqrt(2.*pi.*sigma(1, 3).^2).*exp(-(x-mu(1, 3)).^2./(2.*sigma(1, 3).^2));
f_01 = @(x)sqrt(2.*pi.*sigma(1, 4).^2).*exp(-(x-mu(1, 4)).^2./(2.*sigma(1, 4).^2));
prob_tran = zeros(7, 7);
prob_tran(1, 1) = 1/(2*pi)*integral(f_11, -inf, gamma(1, 1));
prob_tran(1, 2) = 1/(2*pi)*integral(f_11, gamma(1, 1), gamma(1, 2));
prob_tran(1, 3) = 1/(2*pi)*integral(f_11, gamma(1, 2), +inf);

prob_tran(2, 1) = 1/(2*pi)*integral(f_10, -inf, gamma(1, 1));
prob_tran(2, 2) = 1/(2*pi)*integral(f_10, gamma(1, 1), gamma(1, 2));
prob_tran(2, 3) = 1/(2*pi)*integral(f_10, gamma(1, 2), gamma(1, 3));
prob_tran(2, 4) = 1/(2*pi)*integral(f_10, gamma(1, 3), gamma(1, 4));
prob_tran(2, 5) = 1/(2*pi)*integral(f_10, gamma(1, 4), +inf);

prob_tran(3, 3) = 1/(2*pi)*integral(f_00, -inf, gamma(1, 3));
prob_tran(3, 4) = 1/(2*pi)*integral(f_00, gamma(1, 3), gamma(1, 4));
prob_tran(3, 5) = 1/(2*pi)*integral(f_00, gamma(1, 4), gamma(1, 5));
prob_tran(3, 6) = 1/(2*pi)*integral(f_00, gamma(1, 5), gamma(1, 6));
prob_tran(3, 7) = 1/(2*pi)*integral(f_00, gamma(1, 6), +inf);

prob_tran(4, 5) = 1/(2*pi)*integral(f_01, -inf, gamma(1, 5));
prob_tran(4, 6) = 1/(2*pi)*integral(f_01, gamma(1, 5), gamma(1, 6));
prob_tran(4, 7) = 1/(2*pi)*integral(f_01, gamma(1, 6), +inf);

MI        = zeros(1, iter_num);
MI(1, 1)  = MI_Cal(gamma(1, :));
it        = 1;
while(delta_g > epsilon)
    epsilon_vect = zeros(1, m);
    partial_g    = zeros(1, m);
    for i = 1:m
        epsilon_vect(i) = epsilon;
        partial_g(i)    = MI_Cal(gamma(it, :) + epsilon_vect);
    end
    gamma(it + 1, :) = gamma(it, :) + delta_g * partial_g;
    MI(1, it + 1) = MI_Cal(gamma(it + 1, :));
    delta_g = MI(1, it + 1) - MI(1, it);
    fprintf(">> Current iteration number is %d, gamma vector is: [%.2f, %.2f, %.2f, %.2f, %.2f, %.2f]\n", it, gamma(it, 1), gamma(it, 2), gamma(it, 3), gamma(it, 4), gamma(it, 5), gamma(it, 6));
    fprintf(">> Current MI is %.2f\n", MI(1, it + 1));
    it = it + 1;
end