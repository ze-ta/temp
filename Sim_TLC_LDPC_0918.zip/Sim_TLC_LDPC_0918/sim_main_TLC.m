clear all
close all
clc

N           = 8;   % TLC
m           = 14;  % number of read threshold voltage
delta_g     = 10;
delta       = 0.5;
epsilon     = 1e-3;
zeta        = 1e-6;
iter_num    = 1000;
plot_fig    = 0;

% gamma(1, :) = [-4, -2, 0, 1, 1.2, 1.6, 2.0, 2.4, 2.8, 3.2, 3.6, 4.0, 4.4, 4.8];
% mu          = [-3, 1, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0];
mu          = [-7, -5, -3, -1, 1, 3, 5, 7];
% sigma2      = [0.35, 0.12, 0.13, 0.15, 0.2, 0.15, 0.2, 0.15];
Es          = 0;
for i = 1:N
    Es = Es + mu(1, i)^2;
end
Es          = Es/N;
SNR_dB      = 10.2;                  % SNR = 10 dB
N0          = Es*10^(-0.1*SNR_dB); % AWGN N0
% sigma2      = ones(1, 8) * N0/2;   % Noise Variance
% sigma2(1)   = N0;
sigma2      = [N0, N0/2, N0/2, N0/3, N0/3, N0/4, N0/4, N0/4];
sigma = zeros(1, length(sigma2));
for i = 1:length(sigma2)
    sigma(i) = sqrt(sigma2(i));
end

gap         = 0.4;
gamma       = zeros(iter_num, m);
% gamma(1, :) = [-4, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0, 6.5, 7.0];
cp          = [-6, -4, -2, 0, 2, 4, 6]; % cross point
gamma(1, :) = [cp(1) - gap, cp(1) + gap, cp(2) - gap, cp(2) + gap, cp(3) - gap, cp(3) + gap, cp(4) - gap, cp(4) + gap, ...
               cp(5) - gap, cp(5) + gap, cp(6) - gap, cp(6) + gap, cp(7) - gap, cp(7) + gap];

x = -10:0.01:10;
PDF_Func1 = normpdf(x, mu(1), sigma(1));
PDF_Func2 = normpdf(x, mu(2), sigma(2));
PDF_Func3 = normpdf(x, mu(3), sigma(3));
PDF_Func4 = normpdf(x, mu(4), sigma(4));
PDF_Func5 = normpdf(x, mu(5), sigma(5));
PDF_Func6 = normpdf(x, mu(6), sigma(6));
PDF_Func7 = normpdf(x, mu(7), sigma(7));
PDF_Func8 = normpdf(x, mu(8), sigma(8));

if(plot_fig)
    figure(1);
    plot(x, PDF_Func1, '-');
    hold on
    plot(x, PDF_Func2, 'r-');
    plot(x, PDF_Func3, 'Color', [0.3010 0.7450 0.9330]);
    plot(x, PDF_Func4, 'Color', [0.8500 0.3250 0.0980]);
    plot(x, PDF_Func5, 'Color', [0.4660 0.6740 0.1880]);
    plot(x, PDF_Func6, 'Color', [0.9290 0.6940 0.1250]);
    plot(x, PDF_Func7, 'Color', [0.0000 0.4470 0.7410]);
    plot(x, PDF_Func8, 'Color', [0.4940 0.1840 0.5560]);
    grid on
end

MI          = zeros(1, iter_num);
[tmp_MI0, prob_trans] = MI_Cal_All(gamma(1, :), sigma2, mu);
MI(1, 1)    = tmp_MI0;
it          = 1;
while(delta_g > zeta)
    partial_g      = zeros(1, m);
    epsilon_matrix = epsilon * eye(m);
%     epsilon_matrix = epsilon * ones(m);
    for i = 1:m
        [tmp1_gi, ~] = MI_Cal_All(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
        [tmp2_gi, ~] = MI_Cal_All(gamma(it, :), sigma2, mu);
        partial_g(i) = (tmp1_gi - tmp2_gi)/epsilon;
    end
%     partial_g
    gamma(it + 1, :) = gamma(it, :) + delta * partial_g;
    [tmp_MI, prob_trans] = MI_Cal_All(gamma(it + 1, :), sigma2, mu);
%     gamma(it + 1, :)
    prob_trans
    if(tmp_MI - MI(1, it) <= 0)
        gamma(it + 1, :) = gamma(it, :) - delta * partial_g;
        [tmp_MI, prob_trans] = MI_Cal_All(gamma(it + 1, :), sigma2, mu);
    end
    MI(1, it + 1)    = tmp_MI;
    delta_g          = MI(1, it + 1) - MI(1, it);
    fprintf(">> delta g = %.4e\n", delta_g);
    fprintf(">> Current iteration number is %d\n", it);
    fprintf(">> Current MI is %.4f\n", MI(1, it + 1));
    it = it + 1;
end
it
gamma(1, :)
gamma(it, :)
if(plot_fig)
    figure(2)
    plot(1:it, gamma(1:it, 1), 'r-*')
    hold on
    plot(1:it, gamma(1:it, 2), 'b-*')
    plot(1:it, gamma(1:it, 3), 'Color', [0.3010 0.7450 0.9330], 'Marker', '*');
    plot(1:it, gamma(1:it, 4), 'Color', [0.8500 0.3250 0.0980], 'Marker', '*');
    plot(1:it, gamma(1:it, 5), 'Color', [0.4660 0.6740 0.1880], 'Marker', '*');
    plot(1:it, gamma(1:it, 6), 'Color', [0.9290 0.6940 0.1250], 'Marker', '*');
    plot(1:it, gamma(1:it, 7), 'Color', [0.0000 0.4470 0.7410], 'Marker', '*');
    plot(1:it, gamma(1:it, 8), 'Color', [0.4940 0.1840 0.5560], 'Marker', '*');
    grid on
    xlabel('Iterations');ylabel('Read Threshold Voltage');
    title('Read Threshold Voltage vs Iterations')
end

if(plot_fig)
    figure(3)
    len = length(find(MI > 0));
    x = 1:len;
    y = MI(1:len);
    plot(x, y, 'b-o')
    grid on
    xlabel('iterations');ylabel('Mutual Infomation');
    title('MI vs Iterations');
end

LLR_Struct.mu_list        = mu;
LLR_Struct.sigma_list     = sigma2;
Option.Type               = 2;                % 直接输入读电压分区间隔来计算LLR的模式!
Option.LLR_Partition_Voltage = gamma(it,:);

% Option.Type = 2 %表示直接输入读电压分区间隔来计算LLR的模式
% Option.LLR_Partition_Voltage %读电压分区间隔
LLR_and_DV_Sturct = Cal_TLC_LLR(LLR_Struct, Option);
[LLR_and_DV_Sturct.LSB_LLR.' LLR_and_DV_Sturct.MSB_LLR.' LLR_and_DV_Sturct.USB_LLR.']
% [LLR_and_DV_Sturct.LSB_LLR.' LLR_and_DV_Sturct.MSB_LLR.' LLR_and_DV_Sturct.USB_LLR.' LLR_and_DV_Sturct.LSB_LLR_float.' LLR_and_DV_Sturct.MSB_LLR_float.' LLR_and_DV_Sturct.USB_LLR_float.']

% LDPC encoder and decoder
Hb = [...
    -1  -1  -1  -1  197 -1  80  -1  -1  159 9   -1  11  -1  143 -1  -1  -1  -1  121 -1  32  -1  -1  110 -1  -1  -1  154 -1  70  -1  -1  19  -1  -1  230 -1  -1  286 328 -1  -1  -1  -1  -1  257 56  55  -1  -1  0   -1  -1  -1  171 -1  -1  10  289 -1  -1  -1  -1  -1  218 -1  -1  -1  -1  76  327 46  58  27    
    200 -1  -1  93  -1  -1  -1  107 -1  202 -1  222 -1  90  -1  205 -1  -1  -1  87  -1  115 -1  451 4   -1  56  473 -1  -1  47  -1  -1  156 -1  76  -1  -1  372 -1  433 -1  0   -1  -1  7   -1  -1  -1  15  -1  -1  -1  239 289 -1  -1  -1  228 -1  -1  -1  110 -1  -1  239 15  -1  -1  -1  -1  -1  -1  209 -1
    -1  -1  -1  215 -1  -1  -1  91  -1  74  -1  237 202 -1  -1  201 19  -1  147 -1  239 -1  183 482 -1  147 -1  449 -1  -1  -1  234 -1  -1  -1  -1  -1  -1  448 350 294 -1  -1  -1  -1  181 454 -1  -1  -1  23  -1  336 -1  -1  -1  389 -1  -1  -1  375 -1  -1  312 303 -1  -1  443 -1  -1  -1  -1  -1  172 42
    -1  -1  -1  242 -1  80  105 -1  -1  87  -1  43  -1  182 -1  180 -1  134 227 -1  221 -1  77  -1  -1  186 -1  -1  -1  -1  213 -1  -1  -1  -1  19  -1  4   393 498 -1  -1  -1  -1  442 -1  -1  -1  -1  -1  20  -1  445 48  414 -1  -1  -1  -1  329 -1  -1  -1  295 361 -1  -1  -1  205 384 -1  -1  -1  39  234
    452 -1  61  -1  -1  -1  -1  170 250 -1  -1  195 59  -1  -1  36  -1  32  -1  15  -1  92  -1  -1  -1  233 12  -1  -1  207 -1  -1  274 -1  169 -1  159 -1  -1  -1  -1  -1  26  117 -1  -1  -1  -1  -1  84  182 -1  400 -1  -1  -1  -1  17  -1  -1  -1  167 121 496 -1  -1  -1  -1  -1  499 -1  -1  46  242 228
    417 -1  180 -1  -1  114 -1  118 15  -1  93  -1  -1  228 -1  78  -1  16  112 -1  48  -1  73  -1  -1  -1  181 -1  35  -1  -1  11  -1  1   -1  -1  34  -1  -1  -1  -1  -1  112 -1  444 -1  -1  -1  168 -1  -1  73  -1  -1  -1  152 480 -1  -1  -1  -1  22  167 -1  -1  -1  -1  258 5   -1  -1  -1  -1  120 192
    -1  212 249 -1  -1  17  -1  208 37  -1  21  -1  87  -1  103 -1  114 -1  -1  251 46  -1  -1  384 123 -1  -1  -1  -1  295 -1  10  268 -1  -1  -1  -1  14  -1  -1  -1  416 -1  -1  -1  -1  354 158 -1  153 -1  -1  -1  -1  467 -1  -1  313 -1  285 -1  351 -1  -1  -1  -1  -1  -1  -1  -1  150 121 218 -1  45
    -1  16  -1  -1  225 -1  178 -1  -1  123 -1  52  191 -1  141 -1  217 -1  243 -1  97  -1  252 -1  -1  -1  -1  421 -1  -1  -1  -1  368 -1  10  -1  -1  172 -1  -1  -1  29  -1  22  316 -1  -1  -1  400 -1  -1  -1  -1  193 -1  145 -1  -1  234 -1  420 -1  -1  -1  -1  -1  33  320 219 -1  -1  111 -1  202 215
    -1  202 -1  -1  37  -1  3   -1  93  -1  216 -1  -1  57  9   -1  37  -1  -1  191 -1  238 -1  -1  -1  -1  -1  -1  144 472 -1  -1  -1  -1  162 197 -1  -1  -1  -1  -1  172 -1  62  -1  22  -1  19  -1  -1  -1  124 -1  -1  -1  -1  272 152 -1  -1  365 -1  -1  -1  499 134 53  -1  -1  501 110 -1  -1  69  88];

EF = 512;
Hbits = zeros(size(Hb)*EF);
for i = 1:size(Hb,1)
    Ridx = (i-1)*EF+(1:EF);
    for j = 1:size(Hb,2)
        Cidx = (j-1)*EF+(1:EF);
        if(Hb(i,j) ~= -1)
            Hbits(Ridx,Cidx) = circshift(eye(EF), -Hb(i,j));
        end
    end
end
[I1, I2, val] = find(Hbits);
ldpcEncoder = comm.LDPCEncoder(sparse(I1, I2, 1));
MaxIter     = 32;
M           = 4; % Modulation order (QPSK)
SNR         = 6.6:0.1:7.0;
pskMod      = comm.PSKModulator(M,'BitInput',true);
pskDemod    = comm.PSKDemodulator(M,'BitOutput',true,'DecisionMethod','Approximate log-likelihood ratio');
dec_ber     = zeros(1,length(SNR));
unc_ber     = zeros(1,length(SNR));
FER         = zeros(1,length(SNR));
rng('default');
llr_scale   = 13;
maxIt       = 32;
MaxErrFrm   = 100;
short_len   = 384;
puntch_len  = 1344;
sim_para.bd = [1 3 8;1 5 9];
sim_para.v  = [0 1 2 3;0 1 2 3];
sim_para.sat_app  = 63;
sim_para.sat_min  = 15;
t0        = datetime('now');
t1        = datestr(t0, 'yyyy-mm-dd HH:MM:SS');
filename  = strcat('sim_res_',t1(6:7),'_',t1(9:10),'_',t1(12:13),'_',t1(15:16),'_',t1(18:19),'.txt');
fp        = fopen(filename,'w');
info_len  = 4176*8;
code_len  = 4584*8;
SimFrm    = 10^4;
for i = 1:length(SNR)
    TotalErrBit = 0;
    TotalErrUnc = 0;
%     pskDemod.Variance = 1/10^(snr(ii)/20);
    pskDemod.Variance = 1/10^(SNR(i)/10); % Set variance using current SNR
    ErrFrame  = 0;
    TotalIter = 0;
    for j = 1:SimFrm
        if(mod(j, 10^3) == 0)
            fprintf('>> Current SimFrmNum = %d\n', j);
        end
        data1      = logical(randi([0 1],info_len,1));
        data_pad  = [data1;zeros(short_len,1)];       % add zeros
        EncData1   = ldpcEncoder(data_pad);
        EncData1(info_len+1:info_len+short_len) = []; % remove zeros
        
        data2      = logical(randi([0 1],info_len,1));
        data_pad  = [data2;zeros(short_len,1)];       % add zeros
        EncData2   = ldpcEncoder(data_pad);
        EncData2(info_len+1:info_len+short_len) = []; % remove zeros
        
        data3      = logical(randi([0 1],info_len,1));
        data_pad  = [data3;zeros(short_len,1)];       % add zeros
        EncData3   = ldpcEncoder(data_pad);
        EncData3(info_len+1:info_len+short_len) = []; % remove zeros
        
        data_to_NAND=[EncData1,EncData2,EncData3]';
        % add noise
        %--------------------模拟产生阈值电压分布态----------------------------------
        %产生阈值电压, 相当于是写入到NAND闪存
        for ii=1:1:size(data_to_NAND,2)
            if(sum(data_to_NAND(:,ii)==[1;1;1])==3)%E态
                mu1=mu(1);
                sigma1=sigma(1);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1);
                cell_state_num(1,ii)=0;%0代表E态
            elseif(sum(data_to_NAND(:,ii)==[0;1;1])==3)%P1态
                mu1=mu(2);
                sigma1=sigma(2);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1); 
                cell_state_num(1,ii)=1;%1代表P1态
            elseif(sum(data_to_NAND(:,ii)==[0;0;1])==3)%P2态
                mu1=mu(3);
                sigma1=sigma(3);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1);        
                cell_state_num(1,ii)=2;%2代表P2态
            elseif(sum(data_to_NAND(:,ii)==[0;0;0])==3)%P3态
                mu1=mu(4);
                sigma1=sigma(4);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1);        
                cell_state_num(1,ii)=3;%3代表P3态
            elseif(sum(data_to_NAND(:,ii)==[0;1;0])==3)%P4态
                mu1=mu(5);
                sigma1=sigma(5);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1);       
                cell_state_num(1,ii)=4;%4代表P4态
            elseif(sum(data_to_NAND(:,ii)==[1;1;0])==3)%P5态
                mu1=mu(6);
                sigma1=sigma(6);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1);        
                cell_state_num(1,ii)=5;%5代表P5态
            elseif(sum(data_to_NAND(:,ii)==[1;0;0])==3)%P6态
                mu1=mu(7);
                sigma1=sigma(7);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1);        
                cell_state_num(1,ii)=6;%1代表P6态
            elseif(sum(data_to_NAND(:,ii)==[1;0;1])==3)%P7态
                mu1=mu(8);
                sigma1=sigma(8);
                cell_voltage_AWGN(1,ii)=normrnd(mu1,sigma1);        
                cell_state_num(1,ii)=7;%7代表P7态
            else
                disp('Data Error!');
            end
        end
        %figure
%         hold on
%         histogram(cell_voltage_AWGN,305)
        TrueDataFull=cell_state_num;
        %模拟从NAND闪存中读取数据
        ReadDataFull=[];
        DecisionVoltage = LLR_and_DV_Sturct.LSB_DecisionVoltage;
        for rv=1:1:size(DecisionVoltage,2)
            ReadDataFull(rv,:)=double(cell_voltage_AWGN<DecisionVoltage(1,rv));
        end
        %为1的位置代表处于分区区间的位置
        CellVoltageLevel=[];
        for ii=1:1:size(ReadDataFull,2)
            if(isempty(find(ReadDataFull(:,ii)==0)))
                 CellVoltageLevel(1,ii)=1;
            else
                 CellVoltageLevel(1,ii)=max(find(ReadDataFull(:,ii)==0))+1;
            end
        end
        
        %给存储单元赋LLR的值
        LLR_LPage=real(LLR_and_DV_Sturct.LSB_LLR_float);%LLR的值有0可能不行
        LLR_MPage=real(LLR_and_DV_Sturct.MSB_LLR_float);
        LLR_UPage=real(LLR_and_DV_Sturct.USB_LLR_float);
        for ii=1:1:size(CellVoltageLevel,2)
            Cell_LLR_LPage(1,ii)=LLR_LPage(CellVoltageLevel(1,ii));
            Cell_LLR_MPage(1,ii)=LLR_MPage(CellVoltageLevel(1,ii));
            Cell_LLR_UPage(1,ii)=LLR_UPage(CellVoltageLevel(1,ii));
        end
        DemodSig=Cell_LLR_LPage.';
        EncData=EncData1;%low page data
%         EncData1
        %modSig    = pskMod(EncData);
        %rxSig     = awgn(modSig,SNR(ii),'measured'); % AWGN
        %DemodSig  = pskDemod(rxSig);
        %DemodSig  = max(min(round(DemodSig),7),-7);
        
        hard_deci = (DemodSig < 0);  % hard decision
        TotalErrUnc = TotalErrUnc + sum((DemodSig < 0) ~= EncData);
        DemodSig = [DemodSig(1:info_len);ones(short_len,1)*63;DemodSig(info_len+1:end)];
        DemodSig(end-puntch_len+1:end) = 0;
        
        [dec_out,it,~] = ldpc_decoder_layer(-DemodSig,MaxIter,EF,sim_para);
        NumErrbit      = biterr(data1,dec_out(1:length(data1)));
        if(NumErrbit > 0)
            ErrFrame = ErrFrame + 1;
        end
        TotalIter   = TotalIter + it;
        TotalErrBit = TotalErrBit + NumErrbit;
%         decd_data   = dec_out(1:length(data1));
    end
    Miter           = TotalIter/SimFrm;
    TotalBits       = SimFrm*length(dec_out);
    unc_ber(i)      = TotalErrUnc/TotalBits; % unc_ber
    dec_ber(i)      = TotalErrBit/TotalBits; % dec_ber
    FER(i)          = ErrFrame/SimFrm;
    fprintf('>> ==================================\n');
    fprintf('>> Current SNR(dB) = %.2f\n', SNR(i));
    fprintf('>> unc_ber(%d/%d) = %.4e\n', TotalErrUnc, TotalBits, unc_ber(i));
    fprintf('>> dec_ber(%d/%d) = %.4e\n', TotalErrBit, TotalBits, dec_ber(i));
    fprintf('>> FER(%d/%d) = %.2f\n', ErrFrame, SimFrm, FER(i));
    fprintf('>> Miter = %.2f\n', Miter);

    fprintf(fp, '>> ==================================\n');
    fprintf(fp, '>> Current SNR(dB) = %.2f\n', SNR(i));
    fprintf(fp, '>> unc_ber(%d/%d) = %.4e\n', TotalErrUnc, TotalBits, unc_ber(i));
    fprintf(fp, '>> dec_ber(%d/%d) = %.4e\n', TotalErrBit, TotalBits, dec_ber(i));
    fprintf(fp, '>> FER(%d/%d) = %.2f\n', ErrFrame, SimFrm, FER(i));
    fprintf(fp, '>> Miter = %.2f\n', Miter);
end
fclose(fp);