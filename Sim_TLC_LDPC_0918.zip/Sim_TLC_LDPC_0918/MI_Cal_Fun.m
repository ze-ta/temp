function [MI, prob_trans] = MI_Cal_Fun(gamma, sigma2, mu)
N = length(mu);
m = length(gamma);
prob_trans = zeros(N, m + 1);
Vmax =10000;
if(N == 2)
    %% SLC
    f_1 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 1)).^2./(2.*sigma2));
    f_0 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 2)).^2./(2.*sigma2));
    
    prob_trans(1, 1) = 1/(2*pi*sigma2)*integral(f_1, -Vmax, gamma(1, 1));
    prob_trans(1, 2) = 1/(2*pi*sigma2)*integral(f_1, gamma(1, 1), gamma(1, 2));
    prob_trans(1, 3) = 1/(2*pi*sigma2)*integral(f_1, gamma(1, 2), +Vmax);
    
    prob_trans(2, 1) = 1/(2*pi*sigma2)*integral(f_0, -Vmax, gamma(1, 1));
    prob_trans(2, 2) = 1/(2*pi*sigma2)*integral(f_0, gamma(1, 1), gamma(1, 2));
    prob_trans(2, 3) = 1/(2*pi*sigma2)*integral(f_0, gamma(1, 2), +Vmax);
elseif(N == 4)
    %% MLC
    f_11 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 1)).^2./(2.*sigma2));
    f_10 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 2)).^2./(2.*sigma2));
    f_00 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 3)).^2./(2.*sigma2));
    f_01 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 4)).^2./(2.*sigma2));

    prob_trans(1, 1) = 1/(2*pi*sigma2)*integral(f_11, -Vmax, gamma(1, 1));
    prob_trans(1, 2) = 1/(2*pi*sigma2)*integral(f_11, gamma(1, 1), gamma(1, 2));
    prob_trans(1, 3) = 1/(2*pi*sigma2)*integral(f_11, gamma(1, 2), +Vmax);
    
    prob_trans(2, 1) = 1/(2*pi*sigma2)*integral(f_10, -Vmax, gamma(1, 1));
    prob_trans(2, 2) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 1), gamma(1, 2));
    prob_trans(2, 3) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 2), gamma(1, 3));
    prob_trans(2, 4) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 3), gamma(1, 4));
    prob_trans(2, 5) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 4), +Vmax);
    
    prob_trans(3, 3) = 1/(2*pi*sigma2)*integral(f_00, -Vmax, gamma(1, 3));
    prob_trans(3, 4) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 3), gamma(1, 4));
    prob_trans(3, 5) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 4), gamma(1, 5));
    prob_trans(3, 6) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 5), gamma(1, 6));
    prob_trans(3, 7) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 6), +Vmax);
    
    prob_trans(4, 5) = 1/(2*pi*sigma2)*integral(f_01, -Vmax, gamma(1, 5));
    prob_trans(4, 6) = 1/(2*pi*sigma2)*integral(f_01, gamma(1, 5), gamma(1, 6));
    prob_trans(4, 7) = 1/(2*pi*sigma2)*integral(f_01, gamma(1, 6), +Vmax);
elseif(N == 8)
    %% TLC
    f_111 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 1)).^2./(2.*sigma2));
    f_110 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 2)).^2./(2.*sigma2));
    f_100 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 3)).^2./(2.*sigma2));
    f_000 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 4)).^2./(2.*sigma2));
    f_010 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 5)).^2./(2.*sigma2));
    f_011 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 6)).^2./(2.*sigma2));
    f_001 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 7)).^2./(2.*sigma2));
    f_101 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 8)).^2./(2.*sigma2));

    prob_trans(1, 1)  = 1/(2*pi*sigma2)*integral(f_111, -Vmax, gamma(1, 1));
    prob_trans(1, 2)  = 1/(2*pi*sigma2)*integral(f_111, gamma(1, 1), gamma(1, 2));
    prob_trans(1, 3)  = 1/(2*pi*sigma2)*integral(f_111, gamma(1, 2), +Vmax);
    
    prob_trans(2, 1)  = 1/(2*pi*sigma2)*integral(f_110, -Vmax, gamma(1, 1));
    prob_trans(2, 2)  = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 1), gamma(1, 2));
    prob_trans(2, 3)  = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 2), gamma(1, 3));
    prob_trans(2, 4)  = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 3), gamma(1, 4));
    prob_trans(2, 5)  = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 4), +Vmax);
    
    prob_trans(3, 3)  = 1/(2*pi*sigma2)*integral(f_100, -Vmax, gamma(1, 3));
    prob_trans(3, 4)  = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 3), gamma(1, 4));
    prob_trans(3, 5)  = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 4), gamma(1, 5));
    prob_trans(3, 6)  = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 5), gamma(1, 6));
    prob_trans(3, 7)  = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 6), +Vmax);
    
    prob_trans(4, 5)  = 1/(2*pi*sigma2)*integral(f_000, -Vmax, gamma(1, 5));
    prob_trans(4, 6)  = 1/(2*pi*sigma2)*integral(f_000, gamma(1, 5), gamma(1, 6));
    prob_trans(4, 7)  = 1/(2*pi*sigma2)*integral(f_000, gamma(1, 6), gamma(1, 7));
    prob_trans(4, 8)  = 1/(2*pi*sigma2)*integral(f_000, gamma(1, 7), gamma(1, 8));
    prob_trans(4, 9)  = 1/(2*pi*sigma2)*integral(f_000, gamma(1, 8), +Vmax);

    prob_trans(5, 7)  = 1/(2*pi*sigma2)*integral(f_010, -Vmax, gamma(1, 7));
    prob_trans(5, 8)  = 1/(2*pi*sigma2)*integral(f_010, gamma(1, 7), gamma(1, 8));
    prob_trans(5, 9)  = 1/(2*pi*sigma2)*integral(f_010, gamma(1, 8), gamma(1, 9));
    prob_trans(5, 10) = 1/(2*pi*sigma2)*integral(f_010, gamma(1, 9), gamma(1, 10));
    prob_trans(5, 11) = 1/(2*pi*sigma2)*integral(f_010, gamma(1, 10), +Vmax);

    prob_trans(6, 9)  = 1/(2*pi*sigma2)*integral(f_011, -Vmax, gamma(1, 9));
    prob_trans(6, 10) = 1/(2*pi*sigma2)*integral(f_011, gamma(1, 9), gamma(1, 10));
    prob_trans(6, 11) = 1/(2*pi*sigma2)*integral(f_011, gamma(1, 10), gamma(1, 11));
    prob_trans(6, 12) = 1/(2*pi*sigma2)*integral(f_011, gamma(1, 11), gamma(1, 12));
    prob_trans(6, 13) = 1/(2*pi*sigma2)*integral(f_011, gamma(1, 12), +Vmax);

    prob_trans(7, 11) = 1/(2*pi*sigma2)*integral(f_001, -Vmax, gamma(1, 11));
    prob_trans(7, 12) = 1/(2*pi*sigma2)*integral(f_001, gamma(1, 11), gamma(1, 12));
    prob_trans(7, 13) = 1/(2*pi*sigma2)*integral(f_001, gamma(1, 12), gamma(1, 13));
    prob_trans(7, 14) = 1/(2*pi*sigma2)*integral(f_001, gamma(1, 13), gamma(1, 14));
    prob_trans(7, 15) = 1/(2*pi*sigma2)*integral(f_001, gamma(1, 14), +Vmax);

    prob_trans(8, 13) = 1/(2*pi*sigma2)*integral(f_101, -Vmax, gamma(1, 13));
    prob_trans(8, 14) = 1/(2*pi*sigma2)*integral(f_101, gamma(1, 13), gamma(1, 14));
    prob_trans(8, 15) = 1/(2*pi*sigma2)*integral(f_101, gamma(1, 14), +Vmax);
elseif(N == 16)
    %% QLC
else
    fprintf(">> Wrong parameters, please check again!\n");
end

prob_vect = zeros(1, m + 1);
for i = 1:m+1
    prob_vect(i) = sum(prob_trans(:, i))/N;
%     for j = 1:N
%         prob_vect(i) = sum(prob_trans(:, i))/N;
%     end
end
H_Y = EN_Cal(prob_vect);
H_YX = 0;
for i = 1:N
    H_YX = H_YX + EN_Cal(prob_trans(i, :))/N;
end
MI = H_Y - H_YX;
end