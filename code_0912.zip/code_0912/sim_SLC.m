clear all
close all
clc

N           = 2;  % six pdf
m           = 2;
delta_g     = 10;
delta       = 0.5;
epsilon     = 1e-3;
zeta        = 1e-8;
iter_num    = 500;
gamma       = zeros(iter_num, m);
SNR_dB      = 3.8;                    % SNR = 10 dB

EbN0        = 10^(SNR_dB/10);
Eb          = 1;
N0          = Eb/EbN0;
sigma2      = N0/2;
sigma0      = sqrt(sigma2);
sigma1      = sqrt(sigma2);
mu          = [-1, 1];
Eb_N0_dB    = 10*log10(1./((sigma0)^2));

gamma(1, :) = [-2, 2];
MI          = zeros(1, iter_num);
[tmp_MI0, prob_trans] = MI_Cal_tmp(gamma(1, :), sigma2, mu);
MI(1, 1)    = tmp_MI0;
it          = 1;
while(delta_g > zeta)
    partial_g      = zeros(1, m);
    epsilon_matrix = epsilon * eye(m);
    for i = 1:m
        [tmp1_gi, ~] = MI_Cal_tmp(gamma(it, :) + epsilon_matrix(i, :), sigma2, mu);
        [tmp2_gi, ~] = MI_Cal_tmp(gamma(it, :), sigma2, mu);
        partial_g(i) = (tmp1_gi - tmp2_gi)/epsilon;
    end
    gamma(it + 1, :) = gamma(it, :) + delta * partial_g;
    [tmp_MI, ~]   = MI_Cal_tmp(gamma(it + 1, :), sigma2, mu);
    MI(1, it + 1) = tmp_MI;
    delta_g       = MI(1, it + 1) - MI(1, it);
    fprintf(">> delta g = %.4e\n", delta_g);
    gamma(it + 1, 1)
%     fprintf(">> Current iteration number is %d, gamma vector is: [%.4f, %.4f, %.4f, %.4f, %.4f, %.4f]\n", it, gamma(it, 1), gamma(it, 2), gamma(it, 3), gamma(it, 4), gamma(it, 5), gamma(it, 6));
    fprintf(">> Current MI is %.4f\n", MI(1, it + 1));
    it = it + 1;
end
