function [MI, prob_trans] = MI_Cal(gamma, sigma2, mu)
N     = 8;
m     = length(gamma);
% gray_code = [111, 110, 100, 000, 010, 011, 001, 101];
f_111 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 1)).^2./(2.*sigma2));
f_110 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 2)).^2./(2.*sigma2));
f_100 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 3)).^2./(2.*sigma2));
f_000 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 4)).^2./(2.*sigma2));
f_010 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 5)).^2./(2.*sigma2));
f_011 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 6)).^2./(2.*sigma2));
f_001 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 7)).^2./(2.*sigma2));
f_101 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 8)).^2./(2.*sigma2));

prob_trans = zeros(N, m + 1);

prob_trans(1, 1) = 1/(2*pi*sigma2)*integral(f_111, -inf, gamma(1, 1));
prob_trans(1, 2) = 1/(2*pi*sigma2)*integral(f_111, gamma(1, 1), gamma(1, 2));
prob_trans(1, 3) = 1/(2*pi*sigma2)*integral(f_111, gamma(1, 2), +inf);

prob_trans(2, 1) = 1/(2*pi*sigma2)*integral(f_110, -inf, gamma(1, 1));
prob_trans(2, 2) = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 1), gamma(1, 2));
prob_trans(2, 3) = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 2), gamma(1, 3));
prob_trans(2, 4) = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 3), gamma(1, 4));
prob_trans(2, 5) = 1/(2*pi*sigma2)*integral(f_110, gamma(1, 4), +inf);

prob_trans(3, 3) = 1/(2*pi*sigma2)*integral(f_100, -inf, gamma(1, 3));
prob_trans(3, 4) = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 3), gamma(1, 4));
prob_trans(3, 5) = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 4), gamma(1, 5));
prob_trans(3, 6) = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 5), gamma(1, 6));
prob_trans(3, 7) = 1/(2*pi*sigma2)*integral(f_100, gamma(1, 6), +inf);

prob_trans(4, 5) = 1/(2*pi*sigma2)*integral(f_000, -inf, gamma(1, 5));
prob_trans(4, 6) = 1/(2*pi*sigma2)*integral(f_000, gamma(1, 5), gamma(1, 6));
prob_trans(4, 7) = 1/(2*pi*sigma2)*integral(f_000, gamma(1, 6), +inf);




prob_vect = zeros(1, m + 1);
for i = 1:m+1
    prob_vect(i) = (prob_trans(1, i) + prob_trans(2, i) + prob_trans(3, i) + prob_trans(8, i))/8;
end
H_Y = ent_cal(prob_vect);
H_YX = 0;
for i = 1:4
    H_YX = H_YX + ent_cal(prob_trans(i, :))/4;
end
MI = H_Y - H_YX;
end