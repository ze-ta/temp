function entropy = ent_cal(probs)
entropy = 0;
for i = 1:length(probs)
    if(probs(i) == 0)
        entropy = entropy + 0;
    else
        entropy = entropy - probs(i).*log2(probs(i));
    end
end
end