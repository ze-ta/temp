function [MI, prob_trans] = MI_Cal(gamma, sigma2, mu)
m    = length(gamma);
f_11 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 1)).^2./(2.*sigma2));
f_10 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 2)).^2./(2.*sigma2));
f_00 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 3)).^2./(2.*sigma2));
f_01 = @(x) sqrt(2*pi*sigma2).*exp(-(x-mu(1, 4)).^2./(2.*sigma2));
prob_trans = zeros(4, m + 1);

prob_trans(1, 1) = 1/(2*pi*sigma2)*integral(f_11, -inf, gamma(1, 1));
prob_trans(1, 2) = 1/(2*pi*sigma2)*integral(f_11, gamma(1, 1), gamma(1, 2));
prob_trans(1, 3) = 1/(2*pi*sigma2)*integral(f_11, gamma(1, 2), +inf);

prob_trans(2, 1) = 1/(2*pi*sigma2)*integral(f_10, -inf, gamma(1, 1));
prob_trans(2, 2) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 1), gamma(1, 2));
prob_trans(2, 3) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 2), gamma(1, 3));
prob_trans(2, 4) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 3), gamma(1, 4));
prob_trans(2, 5) = 1/(2*pi*sigma2)*integral(f_10, gamma(1, 4), +inf);

prob_trans(3, 3) = 1/(2*pi*sigma2)*integral(f_00, -inf, gamma(1, 3));
prob_trans(3, 4) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 3), gamma(1, 4));
prob_trans(3, 5) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 4), gamma(1, 5));
prob_trans(3, 6) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 5), gamma(1, 6));
prob_trans(3, 7) = 1/(2*pi*sigma2)*integral(f_00, gamma(1, 6), +inf);

prob_trans(4, 5) = 1/(2*pi*sigma2)*integral(f_01, -inf, gamma(1, 5));
prob_trans(4, 6) = 1/(2*pi*sigma2)*integral(f_01, gamma(1, 5), gamma(1, 6));
prob_trans(4, 7) = 1/(2*pi*sigma2)*integral(f_01, gamma(1, 6), +inf);

prob_vect = zeros(1, m + 1);
for i = 1:m+1
    prob_vect(i) = (prob_trans(1, i) + prob_trans(2, i) + prob_trans(3, i) + prob_trans(4, i))/4;
end
H_Y = ent_cal(prob_vect);
H_YX = 0;
for i = 1:4
    H_YX = H_YX + ent_cal(prob_trans(i, :))/4;
end
MI = H_Y - H_YX;
end